//
//  ViewController.swift
//  test2
//
//  Created by Florian Rößler on 20.03.17.
//  Copyright © 2017 swifttest2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var containerView : UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let testurl = URL(string: "https://www.youtube.com/watch?v=UFKBTiylaN4&t=973s")
        let testurlre = URLRequest(url: testurl!)
        containerView.loadRequest(testurlre)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

