# personal portable nvim v0.5.0
#### setup 
add __DESKTOP__ to user environment variable<br>
add path\to\nvim\ to __PATH__ enviornment variable<br>
edit __XDG_CONFIG_HOME__ system environment variable to %DESKTOP% (nvim config then is in %DESKTOP%\nvim\init.vim)<br>


# [nvim source](https://github.com/neovim/neovim)
