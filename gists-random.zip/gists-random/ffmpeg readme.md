# personal portable ffmpeg 2020-12-09
setup for cli add path\to\dir to PATH enviornment variable

## ffplay smal
```batch
@echo off

ffplay -x 720 %1
```

# [source from](https://github.com/GyanD/codexffmpeg)

