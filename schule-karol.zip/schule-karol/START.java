//import javakarol.Welt;

public class START
{
    ROBOTER karol = null;
    WELT welt = null;

    /**
     * Konstruktor f�r Objekte der Klasse Start
     * Veraendere diese Methode, wenn du eine andere Welt haben willst, 
     * oder die Startposition des Roboters veraendern willst.
     */
    public START(int WeltH�he, int WeltBreite, int WeltTiefe)
    {
        welt = new WELT(2,2,30);
        karol= new ROBOTER(1,1,'S',welt);
        karol.VerzoegerungSetzen(1);
        
        int WDH1;
        int WDH2;
        
        WDH1 = WeltH�he * (((WeltBreite - 1) + (WeltTiefe - 1)) * 2);
        WDH2 = WDH1;
        for (int x=0; x > -1; x++){
            for (int y=0; y<WDH1; y++){ 
                if (karol.IstWand()){
                    karol.LinksDrehen();
                }
                if (!karol.IstWand()){
                    karol.Hinlegen();
                    karol.Schritt();
                }
            }
            for (int i=0; i<WDH2; i++){
                if (karol.IstWand()){
                    karol.LinksDrehen();
                }
                if (!karol.IstWand()) {
                    karol.Aufheben();
                    karol.Schritt();
                }
            }
            for (int v=0; v <1; v++){
                karol.LinksDrehen();
            }
        }
    
    }

    /**
     * Diese Methode startet die gew�nschten Aktionen des Roboters.
     */
    public void actionA(){
        while (karol.IstWand()){
             karol.LinksDrehen();
             karol.Hinlegen();
             karol.Schritt();
         }
        while (!karol.IstWand()) {
             karol.Hinlegen();
             karol.Schritt();
         }
    }


    public void actionB()
    {
        while (karol.IstWand()){
            karol.LinksDrehen();
            karol.Aufheben();
            karol.Schritt();
        }
        while (!karol.IstWand()) {
            karol.Aufheben();
            karol.Schritt();
        }
    }

    public void actionC(int WeltH�he, int WeltBreite, int WeltTiefe){
        int WDH1;
        int WDH2;
        
        WDH1 = WeltH�he * (((WeltBreite - 1) + (WeltTiefe - 1)) * 2);
        WDH2 = WDH1;
        for (int x=0; x > -1; x++){
            for (int y=0; y<WDH1; y++){ 
                if (karol.IstWand()){
                    karol.LinksDrehen();
                }
                if (!karol.IstWand()){
                    karol.Hinlegen();
                    karol.Schritt();
                }
            }
            for (int i=0; i<WDH2; i++){
                if (karol.IstWand()){
                    karol.LinksDrehen();
                }
                if (!karol.IstWand()) {
                    karol.Aufheben();
                    karol.Schritt();
                }
            }
            for (int v=0; v <1; v++){
                karol.LinksDrehen();
            }
        }
    }
}












