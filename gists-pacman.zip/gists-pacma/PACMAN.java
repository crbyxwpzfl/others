//Sorry there are no comments in the code, cause I'm lazy :) 
//For questions just ask!
//For introductions read the README!
 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PACMAN extends JFrame implements KeyListener
{
    String text;
    JFrame frame = new JFrame();
    JLabel label = new JLabel(text, JLabel.CENTER);
    
    int keyCode;
    int keyCodeBefor;
    
    Timer timer;
    int Level = 1;
    int LevelImplemented = 3;
    
    boolean PacmanWON = true;
    boolean MonsterWON = false;
    
    boolean MonsterFound = false;
    boolean PacmanFound = false;
    
    String[][] field;
    int fieldSizeY;
    int fieldSizeX;
    
    String[][] field2;
    
    int oldPacmanY;
    int oldPacmanX;
    int newPacmanY;
    int newPacmanX;
    
    int NuberOfMonsters;
    int oldMonsterY;
    int oldMonsterX;
    int newMonsterY;
    int newMonsterX;
    
    int startMonster0Y;
    int startMonster0X;
    
    int startMonster1Y;
    int startMonster1X;
    
    int startMonster2Y;
    int startMonster2X;
    
    int startMonster3Y;
    int startMonster3X;
    
    String[] FieldBefor; 
    String[] FieldAfter;
    
    int Speed = 2;
    int FrameSize = 2;

    String color = "black";
    
    int Star = 0;
    int StarTime;
    
    boolean SuperPacman = false;
    public PACMAN()
    {   
        fieldSizeY = 7;
        fieldSizeX = 1;
        field = new String[fieldSizeY][fieldSizeX];
        
        field[0][0] = "WELCOME TO MY PACMAN";
        field[1][0] = ""; 
        field[2][0] = "";
        field[3][0] = "Press 'p' to play the game";
        field[4][0] = "Press 'i' for the instructions";
        field[5][0] = "Press 'e' to go to the settings";
        field[6][0] = "Press 'q' to quit the game";   
        
        frame.addKeyListener(this);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("PACMAN");
        frame.setSize(500,500);
        frame.getContentPane().setBackground(Color.black);
        
        label.setText(text);
        label.setBounds(0, 0, 500, 500);
        label.setForeground(Color.white);
        label.setFont(new Font("Courier New", Font.PLAIN, 20));
        
        frame.add(label);
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
            
        SHOW.run();
    }
    public static void main(String[] args)
    {
        new PACMAN();
    }
    
    class BLINK implements Runnable//BLINK
    {
        @Override
        public void run()
        {
            if (color == "black")
            {
                frame.getContentPane().setBackground(Color.white);
                label.setForeground(Color.black);
                color = "white";
            }
            else
            {
                if (color == "white")
                {
                    frame.getContentPane().setBackground(Color.black);
                    label.setForeground(Color.white);
                    color = "black";
                }
            }
        }
    }
    BLINK blink = new BLINK();   
    Thread BLINK = new Thread(blink, "BLINK");
    
    class SHOW implements Runnable//SHOW
    {
        @Override
        public void run()
        {
            text = "";
            for (int REP1 = 0; REP1 < fieldSizeY; REP1++){
                for (int REP2 = 0; REP2 < fieldSizeX; REP2++){
                    text = text + field[REP1][REP2];
                }
                text = text + "<br>";
            }
            text = "<html>"  + "<div align=center>" + text + "</div>" + "</html>";
            label.setText(text);
        }
    }
    SHOW show = new SHOW();   
    Thread SHOW = new Thread(show, "SHOW");
    
    class SETTINGS implements Runnable//SETTINGS
    {
        @Override
        public void run()
        {
            if (Speed == 1 && FrameSize == 1)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];            
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "˃ Press '1' for SMAL ˂";
                field[4][0] = "Press '2' for NORMAL";
                field[5][0] = "Press '3' for BIG";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "˃ Press '4' for SLOW ˂";
                field[9][0] = "Press '5' for NORMAL";
                field[10][0] = "Press '6' for FAST";
                
                SHOW.run();
            }
            
            if (Speed == 1 && FrameSize == 2)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];          
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "Press '1' for SMAL";
                field[4][0] = "˃ Press '2' for NORMAL ˂";
                field[5][0] = "Press '3' for BIG";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "˃ Press '4' for SLOW ˂";
                field[9][0] = "Press '5' for NORMAL";
                field[10][0] = "Press '6' for FAST";

                SHOW.run();
            }
            
            if (Speed == 1 && FrameSize == 3)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "Press '1' for SMAL";
                field[4][0] = "Press '2' for NORMAL";
                field[5][0] = "˃ Press '3' for BIG ˂";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "˃ Press '4' for SLOW ˂";
                field[9][0] = "Press '5' for NORMAL";
                field[10][0] = "Press '6' for FAST";
                
                SHOW.run();
            }
            
            if (Speed == 2 && FrameSize == 1)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "˃ Press '1' for SMAL ˂";
                field[4][0] = "Press '2' for NORMAL";
                field[5][0] = "Press '3' for BIG";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "Press '4' for SLOW";
                field[9][0] = "˃ Press '5' for NORMAL ˂";
                field[10][0] = "Press '6' for FAST";
                
                SHOW.run();
            }
            
            if (Speed == 2 && FrameSize == 2)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "Press '1' for SMAL";
                field[4][0] = "˃ Press '2' for NORMAL ˂";
                field[5][0] = "Press '3' for BIG";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "Press '4' for SLOW";
                field[9][0] = "˃ Press '5' for NORMAL ˂";
                field[10][0] = "Press '6' for FAST";
                
                SHOW.run();
            }
            
            if (Speed == 2 && FrameSize == 3)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "Press '1' for SMAL";
                field[4][0] = "Press '2' for NORMAL";
                field[5][0] = "˃ Press '3' for BIG ˂";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "Press '4' for SLOW";
                field[9][0] = "˃ Press '5' for NORMAL ˂";
                field[10][0] = "Press '6' for FAST";
                
                SHOW.run();
            }
            
            if (Speed == 3 && FrameSize == 1)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "˃ Press '1' for SMAL ˂";
                field[4][0] = "Press '2' for NORMAL";
                field[5][0] = "Press '3' for BIG";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "Press '4' for SLOW";
                field[9][0] = "Press '5' for NORMAL";
                field[10][0] = "˃ Press '6' for FAST ˂";
                
                SHOW.run();
            }
            
            if (Speed == 3 && FrameSize == 2)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "Press '1' for SMAL";
                field[4][0] = "˃ Press '2' for NORMAL ˂";
                field[5][0] = "Press '3' for BIG";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "Press '4' for SLOW";
                field[9][0] = "Press '5' for NORMAL";
                field[10][0] = "˃ Press '6' for FAST ˂";
                
                SHOW.run();
            }
            
            if (Speed == 3 && FrameSize == 3)
            {
                fieldSizeY = 11;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];      
                
                field[0][0] = "SETTINGS";
                field[1][0] = "";
                field[2][0] = "SET WINDOW SIZE";
                field[3][0] = "Press '1' for SMAL";
                field[4][0] = "Press '2' for NORMAL";
                field[5][0] = "˃ Press '3' for BIG ˂";
                field[6][0] = "";
                field[7][0] = "SET GAME SPEED";
                field[8][0] = "Press '4' for SLOW";
                field[9][0] = "Press '5' for NORMAL";
                field[10][0] = "˃ Press '6' for FAST ˂";
                
                SHOW.run();
            }
        }
    }
    SETTINGS settings = new SETTINGS();   
    Thread SETTINGS = new Thread(settings, "SETTINGS");
    
    class LEVEL implements ActionListener//LEVEL
    {
        public void actionPerformed(ActionEvent e)
        {
            if (Level == 1)//LEVEL1
            {
                NuberOfMonsters = 3;
                
                startMonster0Y = 7;
                startMonster0X = 6;
                
                startMonster1Y = 7;
                startMonster1X = 7;
                
                startMonster2Y = 7;
                startMonster2X = 8;
                
                StarTime = 50;
                
                fieldSizeY = 15;
                fieldSizeX = 15;
                
                field = new String[fieldSizeY][fieldSizeX];
                FieldBefor = new String[NuberOfMonsters];
                FieldAfter = new String[NuberOfMonsters];
                
                field2 = new String[fieldSizeY][fieldSizeX];
                
                for (int REP1 = 0; REP1 < fieldSizeY; REP1++)
                {
                    for (int REP2 = 0; REP2 < fieldSizeX; REP2++)
                    {    
                        field[REP1][REP2] = "∙";
                    }
                }
                
                field[0][0] = "║"; field[0][2] = "║"; field[0][4] = "═"; field[0][5] = "═"; field[0][6] = "═"; field[0][8] = "═"; field[0][9] = "═"; field[0][10] = "═"; field[0][12] = "║"; field[0][14] = "║";
                field[1][0] = "║"; field[1][2] = "║"; field[1][12] = "║"; field[1][14] = "║";
                field[2][0] = "║"; field[2][2] = "╚"; field[2][3] = "═"; field[2][4] = "═"; field[2][5] = "═"; field[2][6] = "╗"; field[2][8] = "╔"; field[2][9] = "═"; field[2][10] = "═"; field[2][11] = "═"; field[2][12] = "╝"; field[2][14] = "║";
                field[3][6] = "║"; field[3][5] = "○"; field[3][8] = "║"; field[3][9] = "○";
                field[4][0] = "═"; field[4][2] = "═"; field[4][3] = "╦"; field[4][4] = "═"; field[4][5] = "═"; field[4][6] = "╝"; field[4][8] = "╚"; field[4][9] = "═"; field[4][10] = "═"; field[4][11] = "╦"; field[4][12] = "═"; field[4][14] = "═";
                field[5][3] = "║"; field[5][11] = "║";
                field[6][0] = "╔"; field[6][2] = "═"; field[6][3] = "╝"; field[6][5] = "╔"; field[6][6] = "═"; field[6][7] = "─"; field[6][8] = "═"; field[6][9] = "╗"; field[6][11] = "╚"; field[6][12] = "═"; field[6][14] = "╗";
                field[7][0] = "║"; field[7][5] = "║"; field[7][9] = "║"; field[7][14] = "║";
                field[8][0] = "╚"; field[8][2] = "═"; field[8][3] = "╗"; field[8][5] = "╚"; field[8][6] = "═"; field[8][7] = "═"; field[8][8] = "═"; field[8][9] = "╝"; field[8][11] = "╔"; field[8][12] = "═"; field[8][14] = "╝";
                field[9][3] = "║"; field[9][11] = "║";
                field[10][0] = "═"; field[10][2] = "═"; field[10][3] = "╩"; field[10][4] = "═"; field[10][5] = "═"; field[10][6] = "╗"; field[10][8] = "╔"; field[10][9] = "═"; field[10][10] = "═"; field[10][11] = "╩"; field[10][12] = "═"; field[10][14] = "═";
                field[11][6] = "║"; field[11][5] = "○"; field[11][8] = "║"; field[11][9] = "○";
                field[12][0] = "║"; field[12][2] = "╔"; field[12][3] = "═"; field[12][4] = "═"; field[12][5] = "═"; field[12][6] = "╝"; field[12][8] = "╚"; field[12][9] = "═"; field[12][10] = "═"; field[12][11] = "═"; field[12][12] = "╗"; field[12][14] = "║";
                field[13][0] = "║"; field[13][2] = "║"; field[13][12] = "║"; field[13][14] = "║";
                field[14][0] = "║"; field[14][2] = "║"; field[14][4] = "═"; field[14][5] = "═"; field[14][6] = "═"; field[14][8] = "═"; field[14][9] = "═"; field[14][10] = "═"; field[14][12] = "║"; field[14][14] = "║";
                
                field[5][7] = "˂";
                
                field2[6][7] = "<!-- barrier -->";
                
                field[startMonster0Y][startMonster0X] = "x" + "<!-- 0 -->";  
                field[startMonster1Y][startMonster1X] = "x" + "<!-- 1 -->";
                field[startMonster2Y][startMonster2X] = "x" + "<!-- 2 -->";
                
                SHOW.run();
                
                FieldBefor[0] = "&nbsp;"; 
                FieldBefor[1] = "&nbsp;"; 
                FieldBefor[2] = "&nbsp;";
                
                FieldAfter[0] = "&nbsp;"; 
                FieldAfter[1] = "&nbsp;"; 
                FieldAfter[2] = "&nbsp;"; 
                
                timer.stop();
            }
            if (Level == 2)//LEVEL2
            {
                NuberOfMonsters = 3;
                
                startMonster0Y = 7;
                startMonster0X = 6;
                
                startMonster1Y = 7;
                startMonster1X = 7;
                
                startMonster2Y = 7;
                startMonster2X = 8;
                
                StarTime = 50;
                
                fieldSizeY = 15;
                fieldSizeX = 15;
                
                field = new String[fieldSizeY][fieldSizeX];
                FieldBefor = new String[NuberOfMonsters];
                FieldAfter = new String[NuberOfMonsters];
                
                field2 = new String[fieldSizeY][fieldSizeX];
                
                for (int REP1 = 0; REP1 < fieldSizeY; REP1++)
                {
                    for (int REP2 = 0; REP2 < fieldSizeX; REP2++)
                    {    
                        field[REP1][REP2] = "∙";
                    }
                }
                
                field[0][1] = "╔"; field[0][2] = "═"; field[0][4] = "║"; field[0][10] = "║"; field[0][12] = "═"; field[0][13] = "╗";
                field[1][1] = "║"; field[1][4] = "║"; field[1][6] = "║"; field[1][7] = "○"; field[1][8] = "║"; field[1][10] = "║"; field[1][13] = "║";
                field[2][1] = "║"; field[2][3] = "╔"; field[2][4] = "╝"; field[2][6] = "╚"; field[2][7] = "═"; field[2][8] = "╝"; field[2][10] = "╚"; field[2][11] = "╗"; field[2][13] = "║";
                field[3][3] = "║"; field[3][11] = "║";
                field[4][0] = "╔"; field[4][2] = "═"; field[4][3] = "╬"; field[4][4] = "═"; field[4][5] = "═"; field[4][6] = "═"; field[4][8] = "═"; field[4][9] = "═"; field[4][10] = "═"; field[4][11] = "╬"; field[4][12] = "═"; field[4][14] = "╗";
                field[5][0] = "║"; field[5][3] = "║"; field[5][11] = "║"; field[5][14] = "║";
                field[6][0] = "╚"; field[6][1] = "╗"; field[6][3] = "║"; field[6][5] = "╔"; field[6][6] = "═"; field[6][7] = "─"; field[6][8] = "═"; field[6][9] = "╗"; field[6][11] = "║"; field[6][13] = "╔"; field[6][14] = "╝";
                field[7][5] = "║"; field[7][9] = "║";
                field[8][0] = "╔"; field[8][1] = "╝"; field[8][3] = "║"; field[8][5] = "╚"; field[8][6] = "═"; field[8][7] = "─"; field[8][8] = "═"; field[8][9] = "╝"; field[8][11] = "║"; field[8][13] = "╚"; field[8][14] = "╗";
                field[9][0] = "║"; field[9][3] = "║"; field[9][11] = "║"; field[9][14] = "║";
                field[10][0] = "╚"; field[10][2] = "═"; field[10][3] = "╬"; field[10][4] = "═"; field[10][5] = "═"; field[10][6] = "═"; field[10][8] = "═"; field[10][9] = "═"; field[10][10] = "═"; field[10][11] = "╬"; field[10][12] = "═"; field[10][14] = "╝";
                field[11][3] = "║"; field[11][11] = "║";
                field[12][1] = "║"; field[12][3] = "╚"; field[12][4] = "╗"; field[12][6] = "╔"; field[12][7] = "═"; field[12][8] = "╗"; field[12][10] = "╔"; field[12][11] = "╝"; field[12][13] = "║";
                field[13][1] = "║"; field[13][4] = "║"; field[13][6] = "║"; field[13][7] = "○"; field[13][8] = "║"; field[13][10] = "║"; field[13][13] = "║";
                field[14][1] = "╚"; field[14][2] = "═"; field[14][4] = "║"; field[14][10] = "║"; field[14][12] = "═"; field[14][13] = "╝";
                
                field[5][7] = "˂";
                
                field2[6][7] = "<!-- barrier -->";
                field2[8][7] = "<!-- barrier -->";
                
                field[startMonster0Y][startMonster0X] = "x" + "<!-- 0 -->";  
                field[startMonster1Y][startMonster1X] = "x" + "<!-- 1 -->";
                field[startMonster2Y][startMonster2X] = "x" + "<!-- 2 -->";
                
                SHOW.run();
                
                FieldBefor[0] = "&nbsp;"; 
                FieldBefor[1] = "&nbsp;"; 
                FieldBefor[2] = "&nbsp;";
                
                FieldAfter[0] = "&nbsp;"; 
                FieldAfter[1] = "&nbsp;"; 
                FieldAfter[2] = "&nbsp;"; 
                
                timer.stop();
            }
            if (Level == 3)//LEVEL3
            {
                NuberOfMonsters = 4;
                
                startMonster0Y = 1;
                startMonster0X = 1;
                
                startMonster1Y = 1;
                startMonster1X = 13;
                
                startMonster2Y = 13;
                startMonster2X = 1;
                
                startMonster3Y = 13;
                startMonster3X = 13;
                
                StarTime = 50;
                
                fieldSizeY = 15;
                fieldSizeX = 15;
                
                field = new String[fieldSizeY][fieldSizeX];
                FieldBefor = new String[NuberOfMonsters];
                FieldAfter = new String[NuberOfMonsters];
                
                field2 = new String[fieldSizeY][fieldSizeX];
                
                for (int REP1 = 0; REP1 < fieldSizeY; REP1++)
                {
                    for (int REP2 = 0; REP2 < fieldSizeX; REP2++)
                    {    
                        field[REP1][REP2] = "∙";
                    }
                }
                
                field[0][0] = "╔"; field[0][1] = "═"; field[0][2] = "═"; field[0][3] = "═"; field[0][4] = "═"; field[0][5] = "═"; field[0][6] = "═"; field[0][7] = "╦"; field[0][8] = "═"; field[0][9] = "═"; field[0][10] = "═"; field[0][11] = "═"; field[0][12] = "═"; field[0][13] = "═"; field[0][14] = "╗";
                field[1][0] = "║"; field[1][7] = "║"; field[1][14] = "║";
                field[2][0] = "║"; field[2][2] = "═"; field[2][3] = "═"; field[2][4] = "═"; field[2][5] = "═"; field[2][7] = "║"; field[2][9] = "═"; field[2][10] = "═"; field[2][11] = "═"; field[2][12] = "═"; field[2][14] = "║";
                field[3][0] = "║"; field[3][7] = "○"; field[3][14] = "║";
                field[4][0] = "╚"; field[4][1] = "═"; field[4][2] = "╗"; field[4][4] = "═"; field[4][5] = "═"; field[4][6] = "═"; field[4][7] = "═"; field[4][8] = "═"; field[4][9] = "═"; field[4][10] = "═"; field[4][12] = "╔"; field[4][13] = "═"; field[4][14] = "╝";
                field[5][0] = "&nbsp;"; field[5][1] = "&nbsp;"; field[5][2] = "║"; field[5][12] = "║"; field[5][13] = "&nbsp;"; field[5][14] = "&nbsp;";
                field[6][0] = "═"; field[6][1] = "═"; field[6][2] = "╝"; field[6][4] = "║"; field[6][6] = "╔"; field[6][8] = "╗"; field[6][10] = "║"; field[6][12] = "╚"; field[6][13] = "═"; field[6][14] = "═";
                field[7][4] = "║"; field[7][10] = "║";
                field[8][0] = "═"; field[8][1] = "═"; field[8][2] = "╗"; field[8][4] = "║"; field[8][6] = "╚"; field[8][8] = "╝"; field[8][10] = "║"; field[8][12] = "╔"; field[8][13] = "═"; field[8][14] = "═";
                field[9][0] = "&nbsp;"; field[9][1] = "&nbsp;"; field[9][2] = "║"; field[9][12] = "║"; field[9][13] = "&nbsp;"; field[9][14] = "&nbsp;";
                field[10][0] = "╔"; field[10][1] = "═"; field[10][2] = "╝"; field[10][4] = "═"; field[10][5] = "═"; field[10][6] = "═"; field[10][7] = "═"; field[10][8] = "═"; field[10][9] = "═"; field[10][10] = "═"; field[10][12] = "╚"; field[10][13] = "═"; field[10][14] = "╗";
                field[11][0] = "║"; field[11][7] = "○"; field[11][14] = "║";
                field[12][0] = "║"; field[12][2] = "═"; field[12][3] = "═"; field[12][4] = "═"; field[12][5] = "═"; field[12][7] = "║"; field[12][9] = "═"; field[12][10] = "═"; field[12][11] = "═"; field[12][12] = "═"; field[12][14] = "║";
                field[13][0] = "║"; field[13][7] = "║"; field[13][14] = "║";
                field[14][0] = "╚"; field[14][1] = "═"; field[14][2] = "═"; field[14][3] = "═"; field[14][4] = "═"; field[14][5] = "═"; field[14][6] = "═"; field[14][7] = "╩"; field[14][8] = "═"; field[14][9] = "═"; field[14][10] = "═"; field[14][11] = "═"; field[14][12] = "═"; field[14][13] = "═"; field[14][14] = "╝";
                
                field[7][7] = "˂";
                
                field[startMonster0Y][startMonster0X] = "x" + "<!-- 0 -->";  
                field[startMonster1Y][startMonster1X] = "x" + "<!-- 1 -->";
                field[startMonster2Y][startMonster2X] = "x" + "<!-- 2 -->";
                field[startMonster3Y][startMonster3X] = "x" + "<!-- 3 -->";
                
                SHOW.run();
                
                FieldBefor[0] = "&nbsp;"; 
                FieldBefor[1] = "&nbsp;"; 
                FieldBefor[2] = "&nbsp;";
                FieldBefor[3] = "&nbsp;";
                
                FieldAfter[0] = "&nbsp;"; 
                FieldAfter[1] = "&nbsp;"; 
                FieldAfter[2] = "&nbsp;";  
                FieldAfter[3] = "&nbsp;";
                
                timer.stop();
            }
        }
    }
    
    class MOVEMONSTER implements Runnable//MOVEMONSTER
    {
        @Override
        public void run()
        {   
            if (keyCode == 38 || keyCode == 87 || keyCode == 40 || keyCode == 83 || keyCode == 39 || keyCode == 68 || keyCode == 37 || keyCode == 65)
            {   
                for (int REP = 0; REP < NuberOfMonsters; REP++)
                {
                    for (int REP1 = 0; REP1 < fieldSizeY; REP1++)
                    {
                        for (int REP2 = 0; REP2 < fieldSizeX; REP2++)
                        {
                            if (REP == 0)
                            {
                                if (field[REP1][REP2] == "x" + "<!-- 0 -->")
                                {
                                    oldMonsterY = REP1;
                                    oldMonsterX = REP2;
                                    MonsterFound = true;
                                    break;
                                }
                            }
                            
                            if (REP == 1)
                            {
                                if (field[REP1][REP2] == "x" + "<!-- 1 -->")
                                {
                                    oldMonsterY = REP1;
                                    oldMonsterX = REP2;
                                    MonsterFound = true;
                                    break;
                                }
                            }
                            
                            if (REP == 2)
                            {
                                if (field[REP1][REP2] == "x" + "<!-- 2 -->")
                                {
                                    oldMonsterY = REP1;
                                    oldMonsterX = REP2;
                                    MonsterFound = true;
                                    break;
                                }
                            }
                            
                            if (REP == 3)
                            {
                                if (field[REP1][REP2] == "x" + "<!-- 3 -->")
                                {
                                    oldMonsterY = REP1;
                                    oldMonsterX = REP2;
                                    MonsterFound = true;
                                    break;
                                }
                            }
                        }
                        if (MonsterFound == true)
                        {
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    
                    if (MonsterFound == false)
                    {
                        if (REP == 0)
                        {
                            if (field[startMonster0Y][startMonster0X] == "&nbsp;")
                            { 
                                FieldBefor[0] = "&nbsp;"; 
                                FieldAfter[0] = "&nbsp;";
                                oldMonsterY = startMonster0Y;
                                oldMonsterX = startMonster0X;
                                field[startMonster0Y][startMonster0X] = "x" + "<!-- 0 -->"; 
                            }
                            else
                            {
                                if (field[startMonster1Y][startMonster1X] == "&nbsp;")
                                {
                                    FieldBefor[0] = "&nbsp;"; 
                                    FieldAfter[0] = "&nbsp;";
                                    oldMonsterY = startMonster1Y;
                                    oldMonsterX = startMonster1X;
                                    field[startMonster1Y][startMonster1X] = "x" + "<!-- 0 -->"; 
                                }
                                else
                                {
                                    if (field[startMonster2Y][startMonster2X] == "&nbsp;")
                                    {
                                        FieldBefor[0] = "&nbsp;"; 
                                        FieldAfter[0] = "&nbsp;";
                                        oldMonsterY = startMonster2Y;
                                        oldMonsterX = startMonster2X;
                                        field[startMonster2Y][startMonster2X] = "x" + "<!-- 0 -->";
                                    }
                                    else
                                    {
                                        if (field[startMonster3Y][startMonster3X] == "&nbsp;")
                                        {
                                            FieldBefor[0] = "&nbsp;"; 
                                            FieldAfter[0] = "&nbsp;";
                                            oldMonsterY = startMonster3Y;
                                            oldMonsterX = startMonster3X;
                                            field[startMonster3Y][startMonster3X] = "x" + "<!-- 0 -->";
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (REP == 1)
                        {
                            if (field[startMonster0Y][startMonster0X] == "&nbsp;")
                            { 
                                FieldBefor[1] = "&nbsp;"; 
                                FieldAfter[1] = "&nbsp;";
                                oldMonsterY = startMonster0Y;
                                oldMonsterX = startMonster0X;
                                field[startMonster0Y][startMonster0X] = "x" + "<!-- 1 -->"; 
                            }
                            else
                            {
                                if (field[startMonster1Y][startMonster1X] == "&nbsp;")
                                {
                                    FieldBefor[1] = "&nbsp;"; 
                                    FieldAfter[1] = "&nbsp;";
                                    oldMonsterY = startMonster1Y;
                                    oldMonsterX = startMonster1X;
                                    field[startMonster1Y][startMonster1X] = "x" + "<!-- 1 -->"; 
                                }
                                else
                                {
                                    if (field[startMonster2Y][startMonster2X] == "&nbsp;")
                                    {
                                        FieldBefor[1] = "&nbsp;"; 
                                        FieldAfter[1] = "&nbsp;";
                                        oldMonsterY = startMonster2Y;
                                        oldMonsterX = startMonster2X;
                                        field[startMonster2Y][startMonster2X] = "x" + "<!-- 1 -->";
                                    }
                                    else
                                    {
                                        if (field[startMonster3Y][startMonster3X] == "&nbsp;")
                                        {
                                            FieldBefor[1] = "&nbsp;"; 
                                            FieldAfter[1] = "&nbsp;";
                                            oldMonsterY = startMonster3Y;
                                            oldMonsterX = startMonster3X;
                                            field[startMonster3Y][startMonster3X] = "x" + "<!-- 1 -->";
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (REP == 2)
                        {
                            if (field[startMonster0Y][startMonster0X] == "&nbsp;")
                            { 
                                FieldBefor[2] = "&nbsp;"; 
                                FieldAfter[2] = "&nbsp;";
                                oldMonsterY = startMonster0Y;
                                oldMonsterX = startMonster0X;
                                field[startMonster2Y][startMonster2X] = "x" + "<!-- 2 -->"; 
                            }
                            else
                            {
                                if (field[startMonster1Y][startMonster1X] == "&nbsp;")
                                {
                                    FieldBefor[2] = "&nbsp;"; 
                                    FieldAfter[2] = "&nbsp;";
                                    oldMonsterY = startMonster1Y;
                                    oldMonsterX = startMonster1X;
                                    field[startMonster1Y][startMonster1X] = "x" + "<!-- 2 -->"; 
                                }
                                else
                                {
                                    if (field[startMonster2Y][startMonster2X] == "&nbsp;")
                                    {
                                        FieldBefor[2] = "&nbsp;"; 
                                        FieldAfter[2] = "&nbsp;";
                                        oldMonsterY = startMonster2Y;
                                        oldMonsterX = startMonster2X;
                                        field[startMonster2Y][startMonster2X] = "x" + "<!-- 2 -->";
                                    }
                                    else
                                    {
                                        if (field[startMonster3Y][startMonster3X] == "&nbsp;")
                                        {
                                            FieldBefor[2] = "&nbsp;"; 
                                            FieldAfter[2] = "&nbsp;";
                                            oldMonsterY = startMonster3Y;
                                            oldMonsterX = startMonster3X;
                                            field[startMonster3Y][startMonster3X] = "x" + "<!-- 2 -->";
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (REP == 3)
                        {
                            if (field[startMonster0Y][startMonster0X] == "&nbsp;")
                            { 
                                FieldBefor[3] = "&nbsp;"; 
                                FieldAfter[3] = "&nbsp;";
                                oldMonsterY = startMonster0Y;
                                oldMonsterX = startMonster0X;
                                field[startMonster0Y][startMonster0X] = "x" + "<!-- 3 -->"; 
                            }
                            else
                            {
                                if (field[startMonster1Y][startMonster1X] == "&nbsp;")
                                {
                                    FieldBefor[3] = "&nbsp;"; 
                                    FieldAfter[3] = "&nbsp;";
                                    oldMonsterY = startMonster1Y;
                                    oldMonsterX = startMonster1X;
                                    field[startMonster1Y][startMonster1X] = "x" + "<!-- 3 -->"; 
                                }
                                else
                                {
                                    if (field[startMonster2Y][startMonster2X] == "&nbsp;")
                                    {
                                        FieldBefor[3] = "&nbsp;"; 
                                        FieldAfter[3] = "&nbsp;";
                                        oldMonsterY = startMonster2Y;
                                        oldMonsterX = startMonster2X;
                                        field[startMonster2Y][startMonster2X] = "x" + "<!-- 3 -->";
                                    }
                                    else
                                    {
                                        if (field[startMonster3Y][startMonster3X] == "&nbsp;")
                                        {
                                            FieldBefor[3] = "&nbsp;"; 
                                            FieldAfter[3] = "&nbsp;";
                                            oldMonsterY = startMonster3Y;
                                            oldMonsterX = startMonster3X;
                                            field[startMonster3Y][startMonster3X] = "x" + "<!-- 3 -->";
                                        }
                                    }
                                }
                            }
                        }
                    }
                   
                    if (MonsterFound == true)
                    {
                        MonsterFound = false;
                    }
                    
                    if (REP == 0)
                    {
                        int zahl = (int)((Math.random()) * 4 + 1);
                        if (zahl == 1)//UP
                        {
                            newMonsterY = oldMonsterY - 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == -1)
                            {
                                newMonsterY = fieldSizeY - 1;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = fieldSizeY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[0];
                                        FieldAfter[0] = FieldBefor[0];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[0];
                                        FieldAfter[0] = FieldBefor[0];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 2)//DOWN
                        {
                            newMonsterY = oldMonsterY + 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == fieldSizeY)
                            {
                                newMonsterY = 0;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = 0;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[0];
                                        FieldBefor[0] = FieldAfter[0];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY + 1;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[0];
                                        FieldBefor[0] = FieldAfter[0];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 3)//RIGHT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX + 1;
                            
                            if (newMonsterX == fieldSizeX)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = 0;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = 0;
                                        FieldAfter[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[0];
                                        FieldBefor[0] = FieldAfter[0];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX + 1;
                                        FieldAfter[0] = field[newMonsterY][newMonsterX]; 
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[0];
                                        FieldBefor[0] = FieldAfter[0];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 4)//LEFT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX - 1;
                            
                            if (newMonsterX == -1)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = fieldSizeX - 1;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = fieldSizeX - 1;
                                        FieldAfter[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[0];
                                        FieldBefor[0] = FieldAfter[0];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX - 1;
                                        FieldBefor[0] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 0 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[0];
                                        FieldAfter[0] = FieldBefor[0];
                                    }
                                }
                            }
                        }
                    }
                    
                    
                    if (REP == 1)
                    {
                        int zahl = (int)((Math.random()) * 4 + 1);
                        if (zahl == 1)//UP
                        {
                            newMonsterY = oldMonsterY - 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == -1)
                            {
                                newMonsterY = fieldSizeY - 1;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = fieldSizeY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[1];
                                        FieldAfter[1] = FieldBefor[1];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[1];
                                        FieldAfter[1] = FieldBefor[1];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 2)//DOWN
                        {
                            newMonsterY = oldMonsterY + 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == fieldSizeY)
                            {
                                newMonsterY = 0;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = 0;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[1];
                                        FieldBefor[1] = FieldAfter[1];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY + 1;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[1];
                                        FieldBefor[1] = FieldAfter[1];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 3)//RIGHT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX + 1;
                            
                            if (newMonsterX == fieldSizeX)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = 0;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = 0;
                                        FieldAfter[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[1];
                                        FieldBefor[1] = FieldAfter[1];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX + 1;
                                        FieldAfter[1] = field[newMonsterY][newMonsterX]; 
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[1];
                                        FieldBefor[1] = FieldAfter[1];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 4)//LEFT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX - 1;
                            
                            if (newMonsterX == -1)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = fieldSizeX - 1;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = fieldSizeX - 1;
                                        FieldAfter[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[1];
                                        FieldBefor[1] = FieldAfter[1];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX - 1;
                                        FieldBefor[1] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 1 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[1];
                                        FieldAfter[1] = FieldBefor[1];
                                    }
                                }
                            }
                        }
                    }
                    
                    if (REP == 2)
                    {
                        int zahl = (int)((Math.random()) * 4 + 1);
                        if (zahl == 1)//UP
                        {
                            newMonsterY = oldMonsterY - 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == -1)
                            {
                                newMonsterY = fieldSizeY - 1;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = fieldSizeY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[2];
                                        FieldAfter[2] = FieldBefor[2];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[2];
                                        FieldAfter[2] = FieldBefor[2];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 2)//DOWN
                        {
                            newMonsterY = oldMonsterY + 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == fieldSizeY)
                            {
                                newMonsterY = 0;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = 0;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[2];
                                        FieldBefor[2] = FieldAfter[2];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY + 1;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[2];
                                        FieldBefor[2] = FieldAfter[2];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 3)//RIGHT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX + 1;
                            
                            if (newMonsterX == fieldSizeX)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = 0;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = 0;
                                        FieldAfter[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[2];
                                        FieldBefor[2] = FieldAfter[2];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX + 1;
                                        FieldAfter[2] = field[newMonsterY][newMonsterX]; 
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[2];
                                        FieldBefor[2] = FieldAfter[2];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 4)//LEFT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX - 1;
                            
                            if (newMonsterX == -1)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = fieldSizeX - 1;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = fieldSizeX - 1;
                                        FieldAfter[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[2];
                                        FieldBefor[2] = FieldAfter[2];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX - 1;
                                        FieldBefor[2] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 2 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[2];
                                        FieldAfter[2] = FieldBefor[2];
                                    }
                                }
                            }
                        }
                    }
                    
                    if (REP == 3)
                    {
                        int zahl = (int)((Math.random()) * 4 + 1);
                        if (zahl == 1)//UP
                        {
                            newMonsterY = oldMonsterY - 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == -1)
                            {
                                newMonsterY = fieldSizeY - 1;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = fieldSizeY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[3];
                                        FieldAfter[3] = FieldBefor[3];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY - 1;
                                        newMonsterX = oldMonsterX;
                                        FieldBefor[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[3];
                                        FieldAfter[3] = FieldBefor[3];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 2)//DOWN
                        {
                            newMonsterY = oldMonsterY + 1;
                            newMonsterX = oldMonsterX;
                            
                            if (newMonsterY == fieldSizeY)
                            {
                                newMonsterY = 0;
                                newMonsterX = oldMonsterX;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = 0;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[3];
                                        FieldBefor[3] = FieldAfter[3];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY + 1;
                                        newMonsterX = oldMonsterX;
                                        FieldAfter[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[3];
                                        FieldBefor[3] = FieldAfter[3];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 3)//RIGHT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX + 1;
                            
                            if (newMonsterX == fieldSizeX)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = 0;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = 0;
                                        FieldAfter[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[3];
                                        FieldBefor[3] = FieldAfter[3];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX + 1;
                                        FieldAfter[3] = field[newMonsterY][newMonsterX]; 
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[3];
                                        FieldBefor[3] = FieldAfter[3];
                                    }
                                }
                            }
                        }
                        
                        if (zahl == 4)//LEFT
                        {
                            newMonsterY = oldMonsterY;
                            newMonsterX = oldMonsterX - 1;
                            
                            if (newMonsterX == -1)
                            {
                                newMonsterY = oldMonsterY;
                                newMonsterX = fieldSizeX - 1;
                                
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = fieldSizeX - 1;
                                        FieldAfter[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldBefor[3];
                                        FieldBefor[3] = FieldAfter[3];
                                    }
                                }
                            }
                            else
                            {
                                if (SuperPacman == false && (field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                 || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                {
                                    PacmanWON = false;
                                    MonsterWON = true;
                                }
                                else
                                {
                                    if (field[newMonsterY][newMonsterX] == "╔" || field[newMonsterY][newMonsterX] == "╦" || field[newMonsterY][newMonsterX] == "╗"  
                                     || field[newMonsterY][newMonsterX] == "╠" || field[newMonsterY][newMonsterX] == "╬" || field[newMonsterY][newMonsterX] == "╣"
                                     || field[newMonsterY][newMonsterX] == "╚" || field[newMonsterY][newMonsterX] == "╩" || field[newMonsterY][newMonsterX] == "╝"
                                     || field[newMonsterY][newMonsterX] == "║" || field[newMonsterY][newMonsterX] == "═"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 0 -->" 
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 1 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 2 -->"
                                     || field[newMonsterY][newMonsterX] == "x" + "<!-- 3 -->"
                                     || (SuperPacman == true && field[newMonsterY][newMonsterX] == "˂" || field[newMonsterY][newMonsterX] == "˃"
                                     || field[newMonsterY][newMonsterX] == "˄"|| field[newMonsterY][newMonsterX] == "˅"))
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX;
                                    }
                                    else
                                    {
                                        newMonsterY = oldMonsterY;
                                        newMonsterX = oldMonsterX - 1;
                                        FieldBefor[3] = field[newMonsterY][newMonsterX];
                                        field[newMonsterY][newMonsterX] = "x" + "<!-- 3 -->";
                                        field[oldMonsterY][oldMonsterX] = FieldAfter[3];
                                        FieldAfter[3] = FieldBefor[3];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    MOVEMONSTER movemonster = new MOVEMONSTER();   
    Thread MOVEMONSTER = new Thread(movemonster, "MOVEMONSTER");
    
    class MOVEPACMAN implements Runnable//MOVEPACMA
    {    
        @Override
        public void run()
        {   
            while (!Thread.currentThread().isInterrupted())
            {   
                for (int REP1 = 0; REP1 < fieldSizeY; REP1++)
                {
                    for (int REP2 = 0; REP2 < fieldSizeX; REP2++)
                    {
                        if (field[REP1][REP2] == "˂" || field[REP1][REP2] == "˃" || field[REP1][REP2] == "˄" || field[REP1][REP2] == "˅")
                        {
                            oldPacmanY = REP1;
                            oldPacmanX = REP2;
                            PacmanFound = true;
                            break;
                        }
                    }
                    if (PacmanFound == true)
                    {
                        PacmanFound = false;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                
                if (keyCode == 38 || keyCode == 87)//UP
                {
                    newPacmanY = oldPacmanY - 1;
                    newPacmanX = oldPacmanX;
                    
                    if (newPacmanY == -1)//JUMP
                    {
                        newPacmanY = fieldSizeY - 1;
                        newPacmanX = oldPacmanX;
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˅";
                        }
                    }
                    else//NORMAL
                    {
                        if (field[newPacmanY][newPacmanX] == "╔" || field[newPacmanY][newPacmanX] == "╦" || field[newPacmanY][newPacmanX] == "╗"  
                         || field[newPacmanY][newPacmanX] == "╠" || field[newPacmanY][newPacmanX] == "╬" || field[newPacmanY][newPacmanX] == "╣"
                         || field[newPacmanY][newPacmanX] == "╚" || field[newPacmanY][newPacmanX] == "╩" || field[newPacmanY][newPacmanX] == "╝"
                         || field[newPacmanY][newPacmanX] == "║" || field[newPacmanY][newPacmanX] == "═" || field2[newPacmanY][newPacmanX] == "<!-- barrier -->")
                        {
                            newPacmanY = oldPacmanY;
                            newPacmanX = oldPacmanX;
                        }
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˅";
                        }
                    }
                    
                    if (color == "white")
                    {
                        frame.getContentPane().setBackground(Color.black);
                        label.setForeground(Color.white);
                        color = "black";
                    }
                }
                
                if (keyCode == 40 || keyCode == 83)//DOWN
                {
                    newPacmanY = oldPacmanY + 1;
                    newPacmanX = oldPacmanX;
                    
                    if (newPacmanY == fieldSizeY)//JUMP
                    {
                        newPacmanY = 0;
                        newPacmanX = oldPacmanX;
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˄";
                        }
                    }
                    else//NORMAL
                    {
                        if (field[newPacmanY][newPacmanX] == "╔" || field[newPacmanY][newPacmanX] == "╦" || field[newPacmanY][newPacmanX] == "╗"  
                         || field[newPacmanY][newPacmanX] == "╠" || field[newPacmanY][newPacmanX] == "╬" || field[newPacmanY][newPacmanX] == "╣"
                         || field[newPacmanY][newPacmanX] == "╚" || field[newPacmanY][newPacmanX] == "╩" || field[newPacmanY][newPacmanX] == "╝"
                         || field[newPacmanY][newPacmanX] == "║" || field[newPacmanY][newPacmanX] == "═" || field2[newPacmanY][newPacmanX] == "<!-- barrier -->")
                        {
                            newPacmanY = oldPacmanY;
                            newPacmanX = oldPacmanX;
                        }
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˄";
                        }
                    }
                    
                    if (color == "white")
                    {
                        frame.getContentPane().setBackground(Color.black);
                        label.setForeground(Color.white);
                        color = "black";
                    }
                }
                
                if (keyCode == 39 || keyCode == 68)//RIGHT
                {
                    newPacmanY = oldPacmanY;
                    newPacmanX = oldPacmanX + 1;
                    
                    if (newPacmanX == fieldSizeX)//JUMP
                    {
                        newPacmanY = oldPacmanY;
                        newPacmanX = 0;
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˂";
                        }
                    }
                    else//NORMAL
                    {
                        if (field[newPacmanY][newPacmanX] == "╔" || field[newPacmanY][newPacmanX] == "╦" || field[newPacmanY][newPacmanX] == "╗"  
                         || field[newPacmanY][newPacmanX] == "╠" || field[newPacmanY][newPacmanX] == "╬" || field[newPacmanY][newPacmanX] == "╣"
                         || field[newPacmanY][newPacmanX] == "╚" || field[newPacmanY][newPacmanX] == "╩" || field[newPacmanY][newPacmanX] == "╝"
                         || field[newPacmanY][newPacmanX] == "║" || field[newPacmanY][newPacmanX] == "═" || field2[newPacmanY][newPacmanX] == "<!-- barrier -->")
                        {
                            newPacmanY = oldPacmanY;
                            newPacmanX = oldPacmanX;
                        }
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˂";
                        }
                    }
                    
                    if (color == "white")
                    {
                        frame.getContentPane().setBackground(Color.black);
                        label.setForeground(Color.white);
                        color = "black";
                    }
                }
                
                if (keyCode == 37 || keyCode == 65)//LEFT
                {
                    newPacmanY = oldPacmanY;
                    newPacmanX = oldPacmanX - 1;
                    
                    if (newPacmanX == -1)//JUMP
                    {
                        newPacmanY = oldPacmanY;
                        newPacmanX = fieldSizeX - 1;
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˃";
                        }
                    }
                    else//NORMAL
                    {
                        if (field[newPacmanY][newPacmanX] == "╔" || field[newPacmanY][newPacmanX] == "╦" || field[newPacmanY][newPacmanX] == "╗"  
                         || field[newPacmanY][newPacmanX] == "╠" || field[newPacmanY][newPacmanX] == "╬" || field[newPacmanY][newPacmanX] == "╣"
                         || field[newPacmanY][newPacmanX] == "╚" || field[newPacmanY][newPacmanX] == "╩" || field[newPacmanY][newPacmanX] == "╝"
                         || field[newPacmanY][newPacmanX] == "║" || field[newPacmanY][newPacmanX] == "═" || field2[newPacmanY][newPacmanX] == "<!-- barrier -->")
                        {
                            newPacmanY = oldPacmanY;
                            newPacmanX = oldPacmanX;
                        }
                        if (field[newPacmanY][newPacmanX] == "○")
                        {
                            Star = StarTime;
                            SuperPacman = true;
                        }
                        if (SuperPacman == false && (field[newPacmanY][newPacmanX] == "x" + "<!-- 0 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 1 -->" || field[newPacmanY][newPacmanX] == "x" + "<!-- 2 -->"))
                        {
                            PacmanWON = false;
                            MonsterWON = true;
                        }
                        else
                        {
                            field[oldPacmanY][oldPacmanX] = "&nbsp;";
                            field[newPacmanY][newPacmanX] = "˃";
                        }
                    }
                    
                    if (color == "white")
                    {
                        frame.getContentPane().setBackground(Color.black);
                        label.setForeground(Color.white);
                        color = "black";
                    }
                }
                
                MOVEMONSTER.run();
                
                SHOW.run();
                
                if (Speed == 1)
                {
                    try {Thread.sleep(500);}catch(Exception ex){}
                }
                if (Speed == 2)
                {
                    try {Thread.sleep(200);}catch(Exception ex){}
                }
                if (Speed == 3)
                {
                    try {Thread.sleep(100);}catch(Exception ex){}
                }
                
                if (Star > 0 && color == "black")
                {
                    if (Star == 12345)
                    {
                        SuperPacman = true;
                    }
                    else
                    {
                        Star--;
                        if (Star == 0)
                        {
                            SuperPacman = false;
                        }
                    }
                }
                
                if (MonsterWON == false)
                {
                    for (int REP1 = 0; REP1 < fieldSizeY; REP1++)
                    {     
                        for (int REP2 = 0; REP2 < fieldSizeX; REP2++)
                        {
                            if (field[REP1][REP2] == "∙")
                            {
                                PacmanWON = false;
                                break;
                            }
                            else
                            {
                                PacmanWON = true;
                            }
                        }
                        if (PacmanWON == true)
                        {
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                
                if (PacmanWON == true)
                {
                    fieldSizeY = 7;
                    fieldSizeX = 1;
                    field = new String[fieldSizeY][fieldSizeX];      
                    
                    field[0][0] = "CONGRATULATIONS YOU WON";
                    field[1][0] = "";
                    field[2][0] = "";
                    field[3][0] = "Press 'i' for the instructions"; 
                    field[4][0] = "Press 'p' to go to the next level";
                    field[5][0] = "Press 'e' to go to the settings";
                    field[6][0] = "Press 'q' to quit the game"; 
                    
                    Level++;
                    
                    SHOW.run();
                    break;
                }
                
                if (MonsterWON == true)
                {
                    fieldSizeY = 7;
                    fieldSizeX = 1;
                    field = new String[fieldSizeY][fieldSizeX];      
                    
                    field[0][0] = "CONGRATULATIONS YOU LOST";                
                    field[1][0] = "";
                    field[2][0] = "";
                    field[3][0] = "Press 'q' to quit the game";
                    field[4][0] = "Press 'e' to go to the settings";
                    field[5][0] = "Press 'i' for the instructions"; 
                    field[6][0] = "Press 'p' to try again";
                    
                    Level = 1;
                    
                    SHOW.run();
                    break;
                }
            }
        }
    }
    
    @Override
    public void keyPressed(KeyEvent evt)
    {
        keyCode = evt.getKeyCode();
        System.out.println("" + keyCode);
        
        if (keyCode == 192 || keyCode == 153)//SUPER PACMAN
        {
            if (Star == 12345)
            {
                Star = 0;
                SuperPacman = false;
            }
            else
            {
                SuperPacman = true;
                Star = 12345;
            }
        }
        
        if (keyCode == 76)//SET LEVEL
        {
            Level++;
            if (Level > LevelImplemented)
            {
                Level = 1;
            }
        }
        
        if (keyCode == 77 && (PacmanWON == true || MonsterWON == true))//menue
        {
            fieldSizeY = 7;
            fieldSizeX = 1;
            field = new String[fieldSizeY][fieldSizeX];      
            
            field[0][0] = "WELCOME TO MY PACMAN";
            field[1][0] = "";
            field[2][0] = "";
            field[3][0] = "Press 'p' to play the game";
            field[4][0] = "Press 'i' for the instructions";
            field[5][0] = "Press 'e' to go to the settings";
            field[6][0] = "Press 'q' to quit the game"; 
            
            SHOW.run();
        }
        
        if (keyCode == 80 && (PacmanWON == true || MonsterWON == true))//PLAY
        {
            Star = 0;
            SuperPacman = false;
            
            if (Level == 1)
            {
                fieldSizeY = 3;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];
                
                field[0][0] = "LEVEL " + Level;
                field[1][0] = "";
                field[2][0] = "by Flo";
                
                SHOW.run();
                
                timer = new Timer(2000, new LEVEL());
                
                PacmanWON = false;
                MonsterWON = false;
                timer.start();
            }
            if (Level == 2)
            {
                fieldSizeY = 3;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];
                
                field[0][0] = "LEVEL " + Level;
                field[1][0] = "";
                field[2][0] = "by Flo";
                
                SHOW.run();
                
                timer = new Timer(2000, new LEVEL());
                
                PacmanWON = false;
                MonsterWON = false;
                timer.start();
            }
            if (Level == 3)
            {
                fieldSizeY = 3;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];
                
                field[0][0] = "LEVEL " + Level;
                field[1][0] = "";
                field[2][0] = "by Flo";
                
                SHOW.run();
                
                timer = new Timer(2000, new LEVEL());
                
                PacmanWON = false;
                MonsterWON = false;
                timer.start();
            }
            if (Level > LevelImplemented)
            {
                fieldSizeY = 3;
                fieldSizeX = 1;
                field = new String[fieldSizeY][fieldSizeX];
                
                field[0][0] = "CURRENTLY THERE";
                field[1][0] = "ARE NO";
                field[2][0] = "MORE LEVELS";
                
                SHOW.run();
            }
        }
        
        if (keyCode == 69 && (PacmanWON == true || MonsterWON == true))//SETTINGS
        {
            SETTINGS.run();
        }
        
        if (keyCode == 52 && (PacmanWON == true || MonsterWON == true))//SET GAMESPEED
        {
            Speed = 1;
            
            SETTINGS.run();
        }
        
        if (keyCode == 53 && (PacmanWON == true || MonsterWON == true))//SET GAMESPEED
        {
            Speed = 2;
            
            SETTINGS.run();
        }
        
        if (keyCode == 54 && (PacmanWON == true || MonsterWON == true))//SET GAMESPEED
        {
            Speed = 3;
            
            SETTINGS.run();
        }
        
        if (keyCode == 51 && (PacmanWON == true || MonsterWON == true))//SET JFRAMESIZE
        {
            FrameSize = 3;
            
            frame.remove(label);

            frame.setLocation(0,0);
            
            int y = Toolkit.getDefaultToolkit().getScreenSize().width;
            int x = Toolkit.getDefaultToolkit().getScreenSize().height;
           
            frame.setSize(1000,x);

            label.setText(text);
            if (color == "black")
            {
                label.setForeground(Color.white);
            }
            if (color == "white")
            {
                label.setForeground(Color.black);
            }
            label.setBounds(0, 0, 1000, 900);
            label.setFont(new Font("Courier New", Font.PLAIN, 40));
            
            frame.add(label);
            
            frame.setLocationRelativeTo(null);
            
            SHOW.run();
            
            SETTINGS.run();
        }
        
        if (keyCode == 50 && (PacmanWON == true || MonsterWON == true))//SET JFRAMESIZE
        {
            FrameSize = 2;
            
            frame.remove(label);
           
            frame.setSize(500, 500);

            label.setText(text); 
            if (color == "black")
            {
                label.setForeground(Color.white);
            }
            if (color == "white")
            {
                label.setForeground(Color.black);
            }
            label.setBounds(0, 0, 500, 500);
            label.setFont(new Font("Courier New", Font.PLAIN, 20));
            
            frame.add(label);
            
            frame.setLocationRelativeTo(null);

            SHOW.run();
            
            SETTINGS.run();
        }
        
        if (keyCode == 49 && (PacmanWON == true || MonsterWON == true))//SET JFRAMESIZE
        {
            FrameSize = 1;
            
            frame.remove(label);
           
            frame.setSize(300, 300);

            label.setText(text); 
            if (color == "black")
            {
                label.setForeground(Color.white);
            }
            if (color == "white")
            {
                label.setForeground(Color.black);
            }
            label.setBounds(0, 0, 300, 300);
            label.setFont(new Font("Courier New", Font.PLAIN, 10));
        
            frame.add(label);
            
            frame.setLocationRelativeTo(null);

            SHOW.run();
            
            SETTINGS.run();
        }
        
        if (keyCode == 73 && (PacmanWON == true || MonsterWON == true))//INSTRUCTIONS
        {
            
            fieldSizeY = 8;
            fieldSizeX = 1;
            field = new String[fieldSizeY][fieldSizeX];      
            
            field[0][0] = "INSTRUCTIONS";
            field[1][0] = "";
            field[2][0] = "MOVEMENT OF PACMAN";
            field[3][0] = "Use the arrow keys or";
            field[4][0] = "Press 's' to move down";
            field[5][0] = "Press 'd' to move right";
            field[6][0] = "Press 'a' to move left";
            field[7][0] = "Press 'w' to move up";
            
            SHOW.run();
        }
        
        if (keyCode == 27 || keyCode == 81)//EXIT
        {
            System.exit(0);
        }
        
        if ((keyCode == 38 || keyCode == 87 || keyCode == 40 || keyCode == 83 || keyCode == 39 || keyCode == 68 || keyCode == 37 || keyCode == 65) && (PacmanWON == false && MonsterWON == false))//Pause
        {
            if (keyCode == 67)//INVERT COLOR
            {
                BLINK.run();
            }
        }
        else
        {
            if (PacmanWON == false && MonsterWON == false)
            {
                BLINK.run();
            }
            else
            {
                if (keyCode == 67)//INVERT COLOR
                {
                    BLINK.run();
                }
            }
        }
        
        if ((keyCode == 38 || keyCode == 87) && (PacmanWON == false && MonsterWON == false))
        {
            if (Thread.activeCount() == 2)
            { 
                MOVEPACMAN movepacman = new MOVEPACMAN();   
                Thread MOVEPACMAN = new Thread(movepacman, "MOVEPACMAN");
                MOVEPACMAN.start();
            }
        }
        
        if ((keyCode == 40 || keyCode == 83) && (PacmanWON == false && MonsterWON == false))
        {
            if (Thread.activeCount() == 2)
            {  
                MOVEPACMAN movepacman = new MOVEPACMAN();   
                Thread MOVEPACMAN = new Thread(movepacman, "MOVEPACMAN");
                MOVEPACMAN.start();
            }
        }
        
        if ((keyCode == 39 || keyCode == 68) && (PacmanWON == false && MonsterWON == false))
        { 
            if (Thread.activeCount() == 2)
            {         
                MOVEPACMAN movepacman = new MOVEPACMAN();   
                Thread MOVEPACMAN = new Thread(movepacman, "MOVEPACMAN");
                MOVEPACMAN.start();
            }
        }
        
        if ((keyCode == 37 || keyCode == 65)  && (PacmanWON == false && MonsterWON == false))
        {
            if (Thread.activeCount() == 2)
            {
                MOVEPACMAN movepacman = new MOVEPACMAN();   
                Thread MOVEPACMAN = new Thread(movepacman, "MOVEPACMAN");
                MOVEPACMAN.start();
            }
        }
    }
    
    public void keyReleased(KeyEvent evt)
    {
    }
    public void keyTyped(KeyEvent evt)
    {
    }
}